# TP Énergie Solaire - Application de Simulation (VB.NET)

[![Version en Français](https://img.shields.io/badge/Version-Français-green.svg)](#)
[![English Version](https://img.shields.io/badge/Language-English-blue.svg)](README.md)
[![.NET](https://img.shields.io/badge/.NET-8.0-purple.svg)](https://dotnet.microsoft.com/)
[![Plateforme](https://img.shields.io/badge/Plateforme-Windows-lightgrey.svg)](#)

Ce projet est une application Windows Forms développée en **VB.NET** (.NET 8.0) destinée à l'enseignement et à la simulation des principes fondamentaux de l'énergie solaire thermique.

Il regroupe 4 Travaux Pratiques (TPs) interactifs dans une interface unifiée, permettant de modéliser la ressource solaire, les capteurs, le stockage et les assemblages série et/ou parallèle de capteurs solaires thermiques à des fins pédagogiques.

## Nouveauté : Interface Bilingue (Français / Anglais)

Un sélecteur de langue est intégré en haut à droite de l'application :
* Bascule dynamique à tout moment entre le **Français** et l'**Anglais**.
* Traduction instantanée des menus, libellés, listes déroulantes, graphiques (titres, axes, légendes) et synoptiques.

## Fonctionnalités Principales

### 1. TP1 : La Ressource Solaire
Modélisation de la géométrie solaire et de l'irradiation.
*   **Calculs Astronomiques** : Position instantanée du soleil (Hauteur, Azimut) et angles d'incidence.
*   **Visualisation** : Diagramme de la course solaire (Solstices et Équinoxe) avec **marqueur de position (étoile)** pour l'heure calculée.
*   **Puissance** : Estimation de la puissance reçue sur un plan incliné (Modèle simplifié).

### 2. TP2 : Rendement d'un Capteur Plan
Étude de la performance instantanée d'un capteur thermique.
*   **Configuration** : Choix de capteurs (Vitrage simple, double, sélectif) et paramètres physiques ($F_R(\tau\alpha)$, $F_R U_L$).
*   **Simulation** : Calcul du rendement et de la puissance utile en fonction de l'irradiation et des températures.
*   **Graphique Interactif** : Courbe de rendement caractéristique et point de fonctionnement dynamique.
*   **Base de Données** : Lien direct vers la base officielle **Solar Keymark**.

### 3. TP3 : Stockage et Bilan Énergétique
Simulation dynamique du comportement d'un ballon de stockage (ECS).
*   **Modèle Temporel** : Simulation sur 24h par pas de temps (15 min).
*   **Bilan Thermique** : Prise en compte des apports solaires, des pertes statiques et du puisage d'eau chaude (scénario configurable, ex: famille 4 personnes 180 L/jour).
*   **Appoint Électrique** : Puissance maximale d'appoint configurable en kW dans l'IHM.
*   **Météo Variable** : Trois scénarios de temps (**Beau temps, Ciel de traîne, Nuageux**) avec profils de température et d'irradiance distincts.
*   **Visualisation** : Évolution de la température du stock, puissance d'appoint, irradiance et température extérieure sur double axe avec légende sous le graphique.

### 4. TP4 : Assemblage Série vs Parallèle
Dimensionnement de champs de capteurs.
*   **Configuration Hydraulique** : Comparaison des montages Série et Parallèle pour $N$ capteurs.
*   **Calcul Itératif** : Résolution des températures de sortie et des puissances pour chaque capteur du champ.
*   **Interface Intuitive** : Workflow optimisé (Configuration -> Conditions -> Calcul) et synoptique généré dynamiquement.

### Bonus : Mode "Réel"
*   Une option **"Mode Réel"** permet d'injecter du bruit aléatoire (gaussien) sur les mesures (Irradiation, Températures) pour simuler des incertitudes de capteurs et rendre les TPs plus réalistes.

## Architecture Technique

La solution est structurée de manière modulaire :
*   `SolarTPs.Core` : Bibliothèque de classes partagée contenant la logique métier (Physique, Mathématiques, Modèles, Localisation).
    *   `MeteoData` : Données climatiques.
    *   `Capteur` : Modèle physique du capteur.
    *   `SolarGeometry` : Algorithmes astronomiques.
    *   `Simulation` : Moteur de simulation temporelle.
    *   `Localization` : Module de gestion des langues (FR / EN).
*   `SolarTPs.App` : Application Windows Forms (UI).
    *   Utilisation de `System.Windows.Forms.DataVisualization` pour les graphiques.
    *   Contrôles Utilisateurs (`UserControl`) dédiés pour chaque TP.

## Prérequis

*   **IDE** : Visual Studio 2022 (recommandé).
*   **Framework** : .NET 8.0 SDK.
*   **OS** : Windows (Requis pour Windows Forms).

## Installation et Exécution

1.  Cloner le dépôt :
    ```bash
    git clone https://github.com/RvNoel-Fr/tp_solaire.git
    cd tp_solaire
    ```
2.  Ouvrir le fichier de solution `SolarTPs.sln` dans Visual Studio.
3.  Restaurer les packages NuGet (si nécessaire).
4.  Lancer le projet `SolarTPs.App` (F5).

Alternativement, en ligne de commande :
```bash
dotnet restore
dotnet build SolarTPs.App/SolarTPs.App.vbproj
dotnet run --project SolarTPs.App/SolarTPs.App.vbproj
```

## Package Exécutable Prêt à l'Emploi
Un exécutable autonome packagé est disponible dans le dépôt :
* **Dépôt des packages** : [NessieOnLineTools / SolarTPs_Latest.zip](https://github.com/RvNoel-Fr/NessieOnLineTools)

## Auteur
Projet développé dans le cadre des TPs Énergie Solaire.
