# Solar Thermal Energy Lab - Simulation Application (VB.NET)

[![Language: English](https://img.shields.io/badge/Language-English-blue.svg)](#)
[![Version en Français](https://img.shields.io/badge/Version-Français-green.svg)](README_FR.md)
[![.NET](https://img.shields.io/badge/.NET-8.0-purple.svg)](https://dotnet.microsoft.com/)
[![Platform](https://img.shields.io/badge/Platform-Windows-lightgrey.svg)](#)

This project is a Windows Forms desktop application developed in **VB.NET** (.NET 8.0) designed for educational training and simulation of fundamental solar thermal engineering principles.

It brings together 4 interactive practical lab modules (**TP1 to TP4**) in a unified interface, with full **bilingual support (English / French)** that can be toggled dynamically at runtime.

---

## 🌐 Bilingual Support (English / French)

A language selector is available directly in the top-right header:
* Switch seamlessly between **English** and **Français** at any time.
* Live translation of all screens: labels, inputs, dropdown presets, chart titles, secondary axes, legends, synoptic diagrams, and dialog messages.

---

## ☀️ Main Modules

### 1. TP1: Solar Resource
Modeling solar geometry, angles of incidence, and extraterrestrial / clear-sky irradiance.
* **Astronomical Calculations**: Instantaneous solar position (Solar Altitude $h$, Azimuth $\psi$), hour angle ($\omega$), declination ($\delta$), and angle of incidence ($\theta$) on any tilted and oriented collector surface ($\beta, \gamma$).
* **Sun Path Diagram**: Interactive elevation vs. azimuth trajectory across the sky with Solstices (Winter & Summer), Equinox, and the selected day, including a **star marker** for the calculated position.
* **Incident Power & Daily Radiation**: Estimation of hourly received solar power ($W/m^2$) and daily radiation integration ($Wh/m^2$) comparing tilted vs. horizontal planes.

### 2. TP2: Flat-Plate Collector Efficiency
Evaluation of the instantaneous steady-state performance of thermal collectors according to standard **EN 12975**.
* **Presets & Parameters**: Double glazing, evacuated tubes, and unglazed swimming pool collectors with configurable optical efficiency ($\eta_0$), first-order loss coefficient ($a_1$), second-order loss coefficient ($a_2$), surface area ($m^2$), and mass flow rate ($kg/h$).
* **Direct Database Link**: Direct link to the **Solar Keymark** database for real-world collector datasheets.
* **Interactive Charting**: Characteristic efficiency curve $\eta = f((T_m - T_a)/G)$ alongside the iteratively solved operating point (outlet temperature $T_{\text{out}}$, useful power $P_{\text{th}}$, and efficiency $\eta$).

### 3. TP3: Thermal Storage & Energy Balance
Dynamic 24-hour simulation of a domestic hot water (DHW) solar storage tank.
* **Transient Heat Balance**: 15-minute time steps taking into account solar thermal gains from collectors, static standing losses through insulation, and domestic water draw-offs.
* **Configurable Draw-off Schedule**: Hourly water consumption profile (default: 4-person family profile totaling 180 L/day at 7h, 8h, 12h, 19h, and 20h).
* **Backup Auxiliary Heating**: Thermostatic auxiliary heating with an explicit user-configurable maximum power limit ($kW$).
* **Meteorological Profiles**: Three distinct daily weather presets (**Sunny**, **Partly cloudy**, **Overcast**) with realistic temperature and irradiance curves.
* **Dual-Axis Chart**: Simultaneous visualization of tank storage temperature ($^\circ C$), outdoor ambient temperature ($^\circ C$, highlighted in green), solar irradiance ($W/m^2$), and auxiliary backup power ($kW \times 100$) with a clean bottom-docked legend.
* **Energy Metrics**: Solar energy supplied ($kWh$), backup auxiliary energy ($kWh$), solar fraction ($\% $), and net storage energy delta ($kWh$).

### 4. TP4: Array Configurations (Series vs. Parallel)
Hydraulic sizing and thermal behavior of large collector fields.
* **Hydraulic Configurations**: Combine $N$ collectors arranged in parallel rows and series units per row.
* **Iterative Solver**: Individual resolution of fluid temperatures ($T_{\text{in}}$, $T_{\text{out}}$), flow rate, useful power, and efficiency for every single collector in the array, including stagnation detection ($T \ge 95^\circ C$).
* **Dynamic Synoptic Diagram**: Visual GDI+ schematic rendering the array topology, fluid flow paths, and temperature increments at each collector.
* **Global Output**: Total field thermal power ($W$), mixed outlet temperature ($^\circ C$), and total required mass flow ($kg/h$).

---

## 🎲 Bonus Feature: "Real-Time" Mode

An optional **"Real-Time Mode"** checkbox injects Gaussian sensor noise into physical measurements (solar irradiance, temperatures, angles, efficiency) to simulate real-world instrumental uncertainties and measurement noise for students.

---

## 🏗️ Technical Architecture

The solution is divided into two modular projects:
* **`SolarTPs.Core`**: Class library containing physical laws and mathematical models:
  * `SolarGeometry.vb`: Astronomical algorithms (declination, hour angle, elevation, azimuth, incidence).
  * `Capteur.vb`: Collector thermal model (EN 12975 efficiency equations and enthalpy balance).
  * `MeteoData.vb`: Weather and irradiance data structures.
  * `Simulation.vb`: Daily transient simulation engine.
  * `Localization.vb`: Global application language management (English/French).
  * `CollectorPreset.vb`: Collector specifications and presets.
* **`SolarTPs.App`**: Windows Forms presentation layer:
  * Dedicated `UserControl` modules for each lab tab (`TP1Control`, `TP2Control`, `TP3Control`, `TP4Control`).
  * Charting powered by `System.Windows.Forms.DataVisualization`.

---

## ⚙️ Prerequisites

* **Operating System**: Windows 10 / 11 (required for Windows Forms).
* **SDK / Runtime**: [.NET 8.0 SDK](https://dotnet.microsoft.com/download/dotnet/8.0).
* **IDE (Optional)**: Visual Studio 2022, Visual Studio Code, or JetBrains Rider.

---

## 🚀 Installation & Build

### 1. Clone the Repository
```bash
git clone https://github.com/RvNoel-Fr/tp_solaire.git
cd tp_solaire
```

### 2. Build and Run
Using the .NET CLI:
```bash
dotnet restore
dotnet build SolarTPs.App/SolarTPs.App.vbproj
dotnet run --project SolarTPs.App/SolarTPs.App.vbproj
```

Or open `SolarTPs.sln` directly in Visual Studio and press **F5**.

### 3. Prebuilt Executable Package
A prebuilt standalone release package is also maintained in the companion tools repository:
* **Direct Package**: [NessieOnLineTools / SolarTPs_Latest.zip](https://github.com/RvNoel-Fr/NessieOnLineTools)

---

## 📄 License & Authors

Project developed for Solar Thermal Energy engineering coursework and lab simulations.  
Maintained by [RvNoel-Fr](https://github.com/RvNoel-Fr).
